AARVIKA INVESTMENT SERVICES — Website files

FILES
- index.html: complete responsive one-page website with clickable product details, SIP calculator, EMI calculator, embedded InvestWell Scheme Performance section with direct-open fallback, and social links. No build tools or paid plugins required.
- README.txt: publishing instructions.

FREE HOSTING WITH GITHUB PAGES
1. Sign in or create a free GitHub account at https://github.com/
2. Create a new public repository, for example: aarvika-investment-services
3. Upload index.html to the repository root (not inside a nested folder).
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch; branch main and folder /(root); Save.
6. GitHub will show the live URL, typically https://YOUR-USERNAME.github.io/aarvika-investment-services/
   Publishing can take a few minutes.

CALCULATORS AND INVESTWELL
- SIP and EMI calculators run in the visitor's browser and show estimates only.
- The Scheme Performance section embeds the public InvestWell page in an iframe and includes a direct-open fallback. InvestWell may block embedded display or require login; if so, use the button to open the provider page directly. This is not an API integration and does NOT create automatic daily NAV/performance sync. For automated data sync, obtain authorised InvestWell API/feed access or an approved export and permission; never share passwords or OTPs in chat.

ENQUIRY FORM
- The form does not save entries on a server. It opens WhatsApp with the details prefilled; the visitor must review and press Send.
- It uses the WhatsApp number from the supplied digital visiting card: +91 79053 53399.
- The same number is currently used for the Call button. Confirm before launch that this is the correct public call number.

SOCIAL LINKS INCLUDED FROM THE SUPPLIED DIGITAL CARD
- Instagram: https://www.instagram.com/aarvikainvestmentservices/
- Facebook: https://www.facebook.com/1418320074691949
- LinkedIn: https://www.linkedin.com/company/aarvika-investment-services/
- YouTube: YouTube search for AARVIKA INVESTMENT SERVICES, not a verified channel-specific URL.
- Google Business: Google search for the AARVIKA INVESTMENT SERVICES listing, not a direct review link.
- Existing site link from the supplied card was not added as a primary website destination to avoid a self-referencing link.

BEFORE GOING LIVE
- Check every social link and phone number on your own device.
- Add the exact Google Business Profile share/review link if you want a direct listing link.
- Add verified email, full office address, office hours and any required disclosures if appropriate.
- Confirm the actual services/qualifications and any applicable regulatory requirements. Do not add unsupported claims or return promises.
- This site is a static site; it does not automatically connect to Meta, Google Business Profile, Metricool, Windsor.ai or a CRM.
